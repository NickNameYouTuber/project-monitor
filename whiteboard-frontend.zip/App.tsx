import React from 'react';
import WhiteboardPage from './components/WhiteboardPage';

function App() {
  return (
    // 1. h-screen root container: The viewport wrapper
    <div className="h-screen w-screen bg-slate-100 flex flex-col">
      
      {/* 2. flex-1 (stretches): The main workspace area */}
      <div className="flex-1 w-full p-6 flex flex-col min-h-0">
        
        {/* 3. h-full container: The Card/Window that contains the board */}
        <div className="h-full w-full bg-white rounded-xl shadow-2xl flex flex-col overflow-hidden border border-slate-300 relative">
          
          {/* 4. Header: Fixed height header inside the flex container */}
          <header className="h-14 border-b border-slate-200 bg-white flex items-center justify-between px-4 shrink-0 z-10">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">M</div>
              <h1 className="font-semibold text-slate-700 text-sm">Responsive Layout Test</h1>
            </div>
            <div className="flex gap-2">
               <div className="px-3 py-1 text-xs font-medium bg-slate-100 rounded-full text-slate-500">v2.0</div>
            </div>
          </header>

          {/* 4. flex-1 (Body Wrapper): Takes remaining height */}
          <div className="flex-1 relative w-full min-h-0 bg-slate-50">
            
            {/* 5. h-full: The Whiteboard Component Container */}
            <div className="w-full h-full">
               <WhiteboardPage />
            </div>
            
          </div>

        </div>
      </div>
    </div>
  );
}

export default App;